# Copyright 2021 VMware, Inc.
# SPDX-License-Identifier: Apache License 2.0

__version__ = '32.1.3'
